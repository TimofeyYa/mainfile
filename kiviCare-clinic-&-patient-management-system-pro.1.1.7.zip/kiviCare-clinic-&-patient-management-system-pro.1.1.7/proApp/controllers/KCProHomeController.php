<?php

namespace ProApp\controllers;
use ProApp\baseClasses\KCProBase;

class KCProHomeController {

    public function __construct()
    {
    }

    public function isMultiClinicOn () {
        return 'welcome to kivi-care pro' ;
    }
}

