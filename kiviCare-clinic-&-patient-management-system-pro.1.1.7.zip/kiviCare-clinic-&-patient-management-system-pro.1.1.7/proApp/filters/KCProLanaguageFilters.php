<?php

namespace ProApp\filters;
use App\models\KCClinic;
use App\models\KCAppointment;
use App\models\KCBill;
use App\models\KCPatientReport;
use App\baseClasses\KCBase;
use WP_User;
use Twilio\Rest\Client;

class KCProLanaguageFilters extends KCBase {
	public function __construct() {
		global $wpdb;
        $this->db = $wpdb;
		add_filter('kcpro_update_language', [$this, 'updateLang']);
		add_filter('kcpro_change_themecolor', [$this, 'updateThemeColor']);
		add_filter('kcpro_change_mode', [$this, 'updateThemeMode']);
		add_filter('kcpro_upload_logo', [$this, 'uploadLogo']);
		add_filter('kcpro_save_sms_config', [$this, 'saveSmsConfig']);
        add_filter('kcpro_unable_sms_config', [$this, 'toogleSMSConfig']);
		add_filter('kcpro_edit_sms_config', [$this, 'getSmsConfig']);
		add_filter('kcpro_send_sms', [$this, 'sendSMS']);
		add_filter('kcpro_get_prescription_print', [$this, 'getPrescriptionPrint']);
		add_filter('kcpro_upload_patient_report', [$this, 'uploadPatientReport']);
		add_filter('kcpro_get_patient_report', [$this, 'getPatientReport']);
		add_filter('kcpro_view_patient_report', [$this, 'viewPatientReport']);
		add_filter('kcpro_delete_patient_report', [$this, 'deletePatientReport']);
		add_filter('kcpro_get_user_clinic', [$this, 'getUserclinic']);
		add_filter('kcpro_get_sms_template', [$this, 'getSMSTemplate']);
		add_filter('kcpro_save_sms_template', [$this, 'saveSMSTemplate']);
		add_filter('kcpro_get_json_file_data', [$this, 'getJosnData']);
		add_filter('kcpro_save_json_file_data', [$this, 'saveJosnData']);
		add_filter('kcpro_get_all_lang', [$this, 'getAllLang']);
        
    }

    public function updateLang($filterData){
        $upload_dir = wp_upload_dir(); 
        $dir_name = KIVI_CARE_PRO_PREFIX.'lang';
        $user_dirname = $upload_dir['basedir'] . '/' . $dir_name;
        $source_file =$user_dirname.'/'.$filterData['lang']['id'].'.json';
        $target_file = $user_dirname.'/temp.json';
        $lang_data = file_get_contents($source_file);
        copy($source_file, $target_file);
        // if($lang_data !== null && $lang_data !== ''){
        //     file_put_contents($target_file,$lang_data);
        // }
        try{
            if(isset($filterData['user_id'])){
                if(current_user_can('administrator')){
                    update_option( KIVI_CARE_PRO_PREFIX . 'admin_lang',$filterData['lang'] );
                    $data = get_option(KIVI_CARE_PRO_PREFIX . 'admin_lang');

                }else{
                    update_user_meta($filterData['user_id'], 'defualt_lang', $filterData['lang'] );
                    $data = get_user_meta($filterData['user_id'], 'defualt_lang');
                }
                return [
                    'data'=> $data,
                    'status' => true,
                    'message' => esc_html__('Language updated successfully', 'kcp-lang')
                ];
            }
        }catch (Exception $e) {
            return [
                'status' => false,
                'message' => esc_html__('Language updated', 'kcp-lang')
            ];
        }
    }

    public function getPrescriptionPrint($printData){
        try{
            $clinic = new KCClinic;
            $qualifications = [];
            $university =[];
            if(isset($printData['encounter_id'])){
                $patient_encounter_table = $this->db->prefix . 'kc_' . 'patient_encounters';
                $clinics_table           = $this->db->prefix . 'kc_' . 'clinics';
                $users_table             = $this->db->prefix . 'users';
        
                $query = "
                    SELECT {$patient_encounter_table}.*,
                       doctors.display_name  AS doctor_name,
                       patients.display_name AS patient_name,
                       patients.user_email AS patient_email,
                       {$clinics_table}.name AS clinic_name
                    FROM  {$patient_encounter_table}
                       LEFT JOIN {$users_table} doctors
                              ON {$patient_encounter_table}.doctor_id = doctors.id
                      LEFT JOIN {$users_table} patients
                              ON {$patient_encounter_table}.patient_id = patients.id
                       LEFT JOIN {$clinics_table}
                              ON {$patient_encounter_table}.clinic_id = {$clinics_table}.id
                    WHERE {$patient_encounter_table}.id = {$printData['encounter_id']} LIMIT 1";
        
                $encounter = $this->db->get_results( $query, OBJECT );
                $clinicData = $clinic->get_by(['id' => $encounter[0]->clinic_id], '=',true);
                $basic_data  = get_user_meta( $encounter[0]->doctor_id, 'basic_data', true );
                $basic_data = json_decode($basic_data);
                foreach ($basic_data->qualifications as $q) {
                    $qualifications[] =  $q->degree;
                    $qualifications[] =  $q->university;
                }
                $encounter[0]->qualifications = implode (", ", $qualifications);
                $encounter[0]->clinic_address ="#{$clinicData->id } ,{$clinicData->address } ,{$clinicData->city}" ;
                if ( count( $encounter ) ) {
                    return [
                        'data'=> $encounter[0],
                        'status' => true,
                        'message' => esc_html__('Successfully print prescription', 'kcp-lang')
                    ];
                } else {
                    return null;
                }
               
            }
        }catch (Exception $e) {
            return [
                'status' => false,
                'message' => esc_html__('Failed to print', 'kcp-lang')
            ];
        }
    }
    public function updateThemeColor($color){
        try{
            if(isset($color['color'])){
                update_option( KIVI_CARE_PRO_PREFIX . 'theme_color',$color['color'] );
                $data = get_option(KIVI_CARE_PRO_PREFIX . 'theme_color');
                return [
                    'data'=> $data,
                    'status' => true,
                    'message' => esc_html__('Theme Color updated', 'kcp-lang')
                ];
            }
        }catch (Exception $e) {
            return [
                'status' => false,
                'message' => esc_html__('Theme Color not updated', 'kcp-lang')
            ];
        }
    }
    public function uploadLogo($requestData){
        try{
            if(isset($requestData['site_logo'])){
                $requestData['site_logo'] = media_handle_upload('site_logo', 0);
                $data = update_option( KIVI_CARE_PRO_PREFIX . 'site_logo',$requestData['site_logo'] );
                $url = wp_get_attachment_url($requestData['site_logo']);
                return [
                    'data'=> $url,
                    'status' => true,
                    'message' => esc_html__('Theme logo updated', 'kcp-lang')
                ];
            }
        }catch (Exception $e) {
            return [
                'status' => false,
                'message' => esc_html__('Failed to update theme logo', 'kcp-lang')
            ];
        }
    }
    public function updateThemeMode($mode){
        if($mode['mode'] === '1'){
            update_option( KIVI_CARE_PRO_PREFIX . 'theme_mode','true' );
            $data = get_option(KIVI_CARE_PRO_PREFIX . 'theme_mode');
            return [
                'data'=> $data,
                'status' => true,
                'message' => esc_html__('Theme mode updated', 'kcp-lang')
            ];
        }else{
            update_option( KIVI_CARE_PRO_PREFIX . 'theme_mode','false' );
            $data = get_option(KIVI_CARE_PRO_PREFIX . 'theme_mode');
            return [
                'data'=> $data,
                'status' => true,
                'message' => esc_html__('Failed to update theme mode', 'kcp-lang')
            ];
        }
    }
    public function getSmsConfig( $data ) {
		$user_meta = get_user_meta( $data['current_user'], 'sms_config_data', true );
        $user_meta = json_decode( $user_meta );
		if ( $user_meta ) {
			$user_meta = $user_meta;
            return [
                'data'=> $user_meta,
                'status' => true,
            ];
		} else {
            return [
                'data'=> [],
                'status' => false,
            ];
		}
	}
    public function saveSmsConfig($data){
        if(isset($data['current_user'])){
            update_user_meta($data['current_user'], 'sms_config_data', json_encode($data['config_data']));
            return [
                'status' => true,
                'message' => esc_html__('Configuration saved', 'kcp-lang')
            ];
        }else{
            return [
                'status' => false,
                'message' => esc_html__('Configuration not saved', 'kcp-lang')
            ];
        }
	
    }
    public function sendSMS($data){
        global $wpdb;
        $table_name = $wpdb->prefix . 'posts';
        if($data['type'] ==='encounter'){
            $args['post_name'] = strtolower(KIVI_CARE_PRO_PREFIX.'encounter_close');
            $args['post_type'] = strtolower(KIVI_CARE_PRO_PREFIX.'sms_tmp') ;
        }else{
            $args['post_name'] = strtolower(KIVI_CARE_PRO_PREFIX.'add_appointment');
            $args['post_type'] = strtolower(KIVI_CARE_PRO_PREFIX.'sms_tmp') ;
        }

        $query = "SELECT * FROM $table_name WHERE `post_name` = '" . $args['post_name'] . "' AND `post_type` = '".$args['post_type']."' AND post_status = 'publish' ";
        $check_exist_post = $wpdb->get_results($query, ARRAY_A);
        if (count($check_exist_post) > 0) {
            $body = $check_exist_post[0]['post_content'];
        }        
        if($data['type'] ==='encounter'){

            $bill = ( new KCBill )->get_by( [ 'encounter_id' => $data['encounter_id'] ] );
            $patient_detail = get_user_meta($data['patient_id'] ,'basic_data',true);
            $patient_detail =json_decode($patient_detail);

            $get_sms_config  = get_user_meta($data['current_user'],'sms_config_data',true);
            $get_sms_config =json_decode($get_sms_config);

            $key  =  ['{{total_amount}}'];
            if(isset($bill[0]->total_amount)) {
                $body = str_replace($key, $bill[0]->total_amount, $body);
            }
            $sid = $get_sms_config->account_id;
            $token = $get_sms_config->auth_token;
            $twilio = new Client($sid, $token);
            $message = $twilio->messages
            ->create($patient_detail->mobile_number, // to
                    ["body" => wp_strip_all_tags($body), "from" => $get_sms_config->to_number]
            );
            return [
                'status' => true,
            ];
            wp_die();
        }else{
            $appointments = collect((new KCAppointment())->get_by(['id' => $data['appointment_id'] ]));
            $patient_detail = get_user_meta($appointments[0]->patient_id ,'basic_data',true);
            $patient_detail =json_decode($patient_detail);

            $get_sms_config  = get_user_meta($data['current_user'],'sms_config_data',true);
            $get_sms_config =json_decode($get_sms_config);
            $sid = $get_sms_config->account_id;
            $token = $get_sms_config->auth_token;

            $key  =  ['{{appointment_date}}','{{appointment_time}}'];
            foreach($key as $item => $value ){
                switch ($value) {
                    case '{{appointment_date}}':
                        $body = str_replace($value, $appointments[0]->appointment_start_date, $body);
                        break;
                    case '{{appointment_time}}':
                        $body = str_replace($value, $appointments[0]->appointment_start_time, $body);
                        break;
                }
            }
            
            $twilio = new Client($sid, $token);
            $message = $twilio->messages
            ->create($patient_detail->mobile_number, // to
                    ["body" => wp_strip_all_tags($body), "from" => $get_sms_config->to_number]
            );
            return [
                'status' => true,
            ];
            wp_die();
        }
       
    }
    public function uploadPatientReport($formdata){
        $patient_report_table = new KCPatientReport;
        if(isset($formdata['upload_data']['upload_report'])){
            $formdata['upload_data']['upload_report'] = media_handle_upload('upload_report', 0);
        }
        $data = array(
            'name'=> $formdata['upload_data']['name'],
            'patient_id'=>$formdata['upload_data']['patient_id'],
            'date'=> $formdata['upload_data']['date'],
            'upload_report'=>$formdata['upload_data']['upload_report'],
            
        );
        $status = $patient_report_table->insert($data);
        return [
            'status' => true,
            'data'=> $formdata['upload_data']['patient_id'],
            'message' => esc_html__('Add Report Successfully', 'kcp-lang'),
        ];
        wp_die();
    }
    public function getPatientReport($data){
        if(isset($data)){

            $reports = collect((new KCPatientReport())->get_by(['patient_id'=> $data['pid']]));
            return [
                'data'=>$reports,
                'status' => true,
            ];
        }else{
            return [
                'data'=> [],
                'status' => false,
            ];
        }
    }
    public function viewPatientReport($view){
        $reports = collect((new KCPatientReport())->get_by(['patient_id'=> $view['pid'],'id'=>$view['docid']]));
        $url = wp_get_attachment_url($reports[0]->upload_report);
        return [
            'data'=>$url,
            'status' => true,
        ];
    }
    public function deletePatientReport($data){
        $report = new KCPatientReport();
        if(isset($data['report_id'])){
            $report->delete(['id' => $data['report_id']]);
            return [
                'status' => true,
                'message' => esc_html__('Report Deleted Successfully', 'kcp-lang')
            ];
        }else{
            return [
                'status' => false,
                'message' => esc_html__('Report not Deleted Successfully', 'kcp-lang')
            ];
        }
    }
    public function getUserclinic($data){
        $table = $this->db->prefix . 'kc_' . 'doctor_clinic_mappings';
        $table_clinic = $this->db->prefix . 'kc_' . 'clinics';
        if($this->getLoginUserRole() === 'kiviCare_doctor'){
            $user_id = get_current_user_id();
            $docId = $user_id ;
        }else{
            $docId = $data['requestData']['doctor_id'];
        }
        $clinic = "SELECT clinic_id,(SELECT name FROM {$table_clinic} WHERE id= doctor.clinic_id ) as label FROM {$table} as `doctor` 
        WHERE doctor_id =". $docId;
        $clinics = $this->db->get_results( $clinic);
   
        return [
            'status' => true,
            'data'=> $clinics,
        ];
    }
    public function getSMSTemplate(){
        $prefix = KIVI_CARE_PRO_PREFIX;
		$args['post_type'] = strtolower($prefix.'sms_tmp');
		$args['nopaging'] = true;
		$args['post_status'] = 'any' ;
		$template_result = get_posts($args);
		$template_result = collect($template_result)->unique('post_title')->sortBy('ID');
		
		if ($template_result) {
            return [
                'status' => true,
                'data'=> $template_result,
            ];
		} else {
			echo json_encode([
				'status' => false,
				'data' => []
			]);
		}
    }
    public function saveSMSTemplate($data){
        foreach ($data['data'] as $key => $value) {
			wp_update_post($value);
		}

		echo json_encode([
			'status' => true,
			'message' => esc_html__('SMS template  saved successfully.', 'kcp-lang')
		]);
    }
    public function getJosnData($file){
        //english
        $upload_dir = wp_upload_dir(); 
        $dir_name = KIVI_CARE_PRO_PREFIX.'lang';
		$user_dirname = $upload_dir['basedir'] . '/' . $dir_name;
        $current_file = $user_dirname.'/en.json';

        if(!file_exists($current_file)) {
	        $current_file = $user_dirname.'/temp.json';
        }

        $str = file_get_contents($current_file);
        $json = json_decode($str, true);

        $json = collect($json);
        $data = $json->map( function ( $d ) {
            if(gettype($d) === 'object'){
                $d = json_decode($d,true);
            }
          return $d;
        });

        // other language
        $current_file_1 = $user_dirname.'/'.$file['currentFile'].'.json';
        $str1 = file_get_contents($current_file_1);
        $json1 = json_decode($str1, true);

        $json1 = collect($json1);
        $data1 = $json1->map( function ( $d ) {
            if(gettype($d) === 'object'){
                $d = json_decode($d,true);
            }
          return $d;
        });
        $newlang = $file['currentFile'];
        wp_send_json([
            'status' => true,
            'data'=> [
                'en' => $data->toArray(),
                $newlang=> !empty($data1->toArray()) ? $data1->toArray() :$data->toArray()
            ],
        ]);
    }
    public function saveJosnData($requestData){
       
       $prefix = KIVI_CARE_PRO_PREFIX;

       $upload_dir = wp_upload_dir(); 
       $dir_name = $prefix .'lang';
       $user_dirname = $upload_dir['basedir'] . '/' . $dir_name;

       $data = $requestData['jsonData'];
       $file_name =$user_dirname.'/'.$requestData['filename'].'.json';
       $data = json_encode($data);
       $save_lang = [
           'label'=> $requestData['langName'],
           'id'=>$requestData['filename']
       ];   
       $get_lang_option = get_option($prefix.'lang_option');
       $get_lang_option = json_decode($get_lang_option,true);
       $collection = collect($get_lang_option['lang_option'] );
        $result = $collection->where('id', $requestData['filename']);
        if(count($result) == 0){
            array_push($get_lang_option['lang_option'],$save_lang);
            update_option( $prefix.'lang_option',json_encode($get_lang_option));
        
        }
       if(file_put_contents($file_name,$data)){
        chmod($file_name, 0777); 

        $get_admin_lang = get_option(KIVI_CARE_PRO_PREFIX . 'admin_lang');
        if($get_admin_lang['id'] == $requestData['filename']){
            $temp_file_name = $user_dirname.'/temp.json';
            file_put_contents($temp_file_name,$data);
        }
        return [
            'status' => true,
            'message' => esc_html__('Language File Updated successfully.', 'kcp-lang')
        ];
       }else{
        return [
            'status' => false,
            'message' => esc_html__('Failed to update file', 'kcp-lang')
        ];
       }

       
    }
    public function getAllLang(){
        $prefix = KIVI_CARE_PRO_PREFIX;
        $lang_option = get_option($prefix . 'lang_option');
		if($lang_option !== '') {
            $data = json_decode($lang_option);
			$status = true ;
		} else {
			$data = [] ;
			$status = false ;
        }
        return [
            'status' => $status,
            'data'    => $data
        ];
    }
    public function toogleSMSConfig($data){
        if($data['status'] === 'false'){
            $status = "false";
        }else{
            $status ="true";
        }
        if(isset($data['current_user'])){
            update_user_meta($data['current_user'], 'is_enable_sms', $status);
            return [
                'status' => true,
                'message' => esc_html__('Configuration saved', 'kcp-lang')
            ];
        }else{
            return [
                'status' => false,
                'message' => esc_html__('Configuration not saved', 'kcp-lang')
            ];
        }
    }

}