<?php

namespace ProApp\filters;

use App\models\KCPatientReport;
use App\baseClasses\KCBase;
use WP_User;

class KCProPatientReport extends KCBase {

	public function __construct() {
		global $wpdb;
        $this->db = $wpdb;
        
        add_filter('kcapro_upload_patient_report', [$this, 'uploadPatientReport']);
        add_filter('kcapro_get_patient_report', [$this, 'getPatientReport']);
        add_filter('kcapro_delete_patient_report', [$this, 'deletePatientReport']);
    }

    public function getPatientReport($parameters)
    {
        $limit  = (isset($parameters['limit']) && $parameters['limit'] != '' ) ? $parameters['limit'] : 10;
        $page = (isset($parameters['page']) && $parameters['page'] != '' ) ? $parameters['page'] : 1;
        $offset = ( $page - 1 ) *  $limit;

        $report_table = $this->db->prefix. 'kc_' . 'patient_medical_report';

        $query = "SELECT * FROM $report_table";
        
        if(isset($parameters['patient_id']) && $parameters['patient_id'] != null){
            $query = $query. " WHERE patient_id = {$parameters['patient_id']} ";
        }

        $report_count = $this->db->get_results($query,OBJECT);
        $query = $query. " ORDER BY id ASC LIMIT {$limit} OFFSET {$offset} ";

        $report_list = $this->db->get_results($query,OBJECT);

        $response['total'] = count($report_count);
        if($response['total'] > 0)
        {
            $report_list = collect($report_list)->map(function ( $report) {
                $report->upload_report_url = (wp_get_attachment_url($report->upload_report) !== false) ? wp_get_attachment_url($report->upload_report) : null;
                return $report;
            });
        }
		$response['data']  = $report_list;

        return $response;
    }

    public function uploadPatientReport($parameters)
    {
        $report_table = $this->db->prefix.'kc_' .'patient_medical_report';

		if( isset($parameters['upload_report']) && $parameters['upload_report'] != null ){
			$parameters['upload_report'] = media_handle_upload( 'upload_report', 0 );
		}
        $temp = array(
            'name'			=> $parameters['name'],
            'patient_id' 	=> $parameters['patient_id'],
            'date'			=> $parameters['date'],
            'upload_report'	=> $parameters['upload_report'], 
        );
        $this->db->insert($report_table , $temp);
        $response = [
            'status' => 200,
            'message' => 'Report added successfully',
        ];
        return $response;
    }

    public function deletePatientReport($parameters)
    {
        $report_table = $this->db->prefix.'kc_' .'patient_medical_report';
		$report_id = $parameters['report_id'];

		$report_data = $this->db->get_row("SELECT * FROM {$report_table} WHERE id = {$report_id}", OBJECT );

		$message = 'Report delete failed';
		if(!empty($report_data)){
			wp_delete_attachment($report_data->upload_report);
			$this->db->delete( $report_table , array ('id' => $report_id) );
			$message = 'Report has been deleted successfully';
		}

        return $message;
    }
}
