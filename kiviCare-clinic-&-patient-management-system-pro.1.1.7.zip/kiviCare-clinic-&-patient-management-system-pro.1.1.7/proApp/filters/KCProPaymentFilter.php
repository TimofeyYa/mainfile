<?php
namespace ProApp\filters ;

use ProApp\baseClasses\KCProHelper;

use App\baseClasses\KCBase;
use App\models\KCAppointment;
use App\models\KCAppointmentServiceMapping;

class KCProPaymentFilter extends KCBase {

    public function __construct() {
    }
       // check is woocommerce enable
    public static function woocommerceIsEnabled() {
		return class_exists( 'WooCommerce', false );
	}
    // appointment service add to cart
    public function wooocommerceAddToCart ($filterData) {
        $kiviWooProductId = $this->kivicareWoocommerceProduct();
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            
            global $woocommerce;
            $patient_data = kcGetUserData($filterData['patient_id']);
            
            $address = array(
                'first_name' => $patient_data->first_name,
                'last_name'  => $patient_data->last_name,
                'company'    => '',
                'email'      => $patient_data->user_email,
                'phone'      => isset($patient_data->basicData) && isset($patient_data->basicData->mobile_number) ? $patient_data->basicData->mobile_number : null ,
                'address_1'  => isset($patient_data->basicData) && isset($patient_data->basicData->address) ? $patient_data->basicData->address : null ,
                'address_2'  => isset($patient_data->basicData) && isset($patient_data->basicData->address) ? $patient_data->basicData->address : null ,
                'city'       => isset($patient_data->basicData) && isset($patient_data->basicData->city) ? $patient_data->basicData->city : null ,
                'state'      => "",
                'postcode'   => isset($patient_data->basicData) && isset($patient_data->basicData->postal_code) ? $patient_data->basicData->postal_code : null ,
                'country'    => isset($patient_data->basicData) && isset($patient_data->basicData->country) ? $patient_data->basicData->country : null ,
            );
          
            // Now we create the order
            $order = wc_create_order();
          
            $objProduct = wc_get_product($kiviWooProductId);
            
            // if ( $objProduct instanceof WC_Product) {

                $appointment_id = $filterData['appointment_id'];
                $appointment_services = (new KCAppointmentServiceMapping())->get_by([
                    'appointment_id' => $appointment_id,
                ]);
    
                $charges = 0 ;
        
                foreach ($appointment_services as $key => $value) {

                    $service_charges = kcGetServiceCharges([
                        'service_id' => $value->service_id,
                        'doctor_id' =>  $filterData['doctor_id']
                    ]);
                    
                    $service_name = kcGetServiceById($value->service_id);
                    $objProduct->set_name($service_name->name);
                    $objProduct->set_price($service_charges->charges);

                    $order->add_product( $objProduct );
                }
            // }
            
            // This is an existing SIMPLE product
            $order->set_address( $address, 'billing' );
            $order->set_customer_id( $filterData['patient_id'] );
            $order->calculate_totals();
            $order->update_status("Completed", 'Imported order', TRUE);

            // wc_add_order_item_meta($kiviWooProductId, 'kivicare_appointment_id', $filterData['appointment_id'] );
            // wc_add_order_item_meta($kiviWooProductId, 'doctor_id', $filterData['doctor_id'] );

            return [
                'status'  => true,
                'woocommerce_redirect' => $order->get_checkout_payment_url()
            ];

        }else {
            $this->setWoocommerCustomerCookie();
            WC()->cart->empty_cart();
        
            WC()->cart->add_to_cart( $kiviWooProductId, 1, '', [], ['kivicare_appointment_id' => $filterData['appointment_id'], 'doctor_id' => $filterData['doctor_id']] );
        }

		return [
			'status'  => true,
            'woocommerce_redirect' => wc_get_cart_url()
        ];
    }

    // set cookie for woocommerce payment
    private static function setWoocommerCustomerCookie() {
        
        if ( WC()->session && WC()->session instanceof \WC_Session_Handler && WC()->session->get_session_cookie() === false )
		{
			WC()->session->set_customer_session_cookie( true );
		}

		return true;
    }

    public static function kivicareWoocommerceProduct() {

        $kiviWooProductId = (new KCProHelper)->getOption('woocommerce_product_id');
        if($kiviWooProductId)
		{
			$kivicareWooPoductInfo = wc_get_product( $kiviWooProductId );

        }
        
        if(!$kiviWooProductId || !$kivicareWooPoductInfo || !$kivicareWooPoductInfo->exists() || $kivicareWooPoductInfo->get_status() != 'publish') {
            $kiviWooProductId = wp_insert_post([
				'post_title'    => 'Appointment Fees',
				'post_type'     => 'product',
				'post_status'   => 'publish'
            ]);
            
            (new KCProHelper)->updateOption('woocommerce_product_id', $kiviWooProductId);

            wp_set_object_terms( $kiviWooProductId, 'simple', 'product_type' );

            update_post_meta( $kiviWooProductId, '_visibility', 'hidden' );
			update_post_meta( $kiviWooProductId, '_stock_status', 'instock');
			update_post_meta( $kiviWooProductId, 'total_sales', '0' );
			update_post_meta( $kiviWooProductId, '_downloadable', 'no' );
			update_post_meta( $kiviWooProductId, '_virtual', 'yes' );
			update_post_meta( $kiviWooProductId, '_regular_price', '0' );
			update_post_meta( $kiviWooProductId, '_sale_price', '' );
			update_post_meta( $kiviWooProductId, '_purchase_note', '' );
			update_post_meta( $kiviWooProductId, '_featured', 'no' );
			update_post_meta( $kiviWooProductId, '_weight', '' );
			update_post_meta( $kiviWooProductId, '_length', '' );
			update_post_meta( $kiviWooProductId, '_width', '' );
			update_post_meta( $kiviWooProductId, '_height', '' );
			update_post_meta( $kiviWooProductId, '_sku', '' );
			update_post_meta( $kiviWooProductId, '_product_attributes', [] );
			update_post_meta( $kiviWooProductId, '_sale_price_dates_from', '' );
			update_post_meta( $kiviWooProductId, '_sale_price_dates_to', '' );
			update_post_meta( $kiviWooProductId, '_price', '0' );
			update_post_meta( $kiviWooProductId, '_sold_individually', 'yes' );
			update_post_meta( $kiviWooProductId, '_manage_stock', 'no' );
			update_post_meta( $kiviWooProductId, '_backorders', 'no' );
			wc_update_product_stock($kiviWooProductId, 0, 'set');
			update_post_meta( $kiviWooProductId, '_stock', '' );

        }

        return $kiviWooProductId;
    }
    public static function cartProductPrice ( $product_price, $cart_item, $cart_item_key ) {
        if(count($cart_item) > 0) {

            $appointment_id = $cart_item['kivicare_appointment_id'] ;

            $appointment_services = (new KCAppointmentServiceMapping())->get_by([
                'appointment_id' => $appointment_id,
            ]);

            $charges = 0 ;

            if(count($appointment_services) > 0) {

                foreach ($appointment_services as $key => $value) {

                    $service_charges = kcGetServiceCharges([
                        'service_id' => $value->service_id,
                        'doctor_id' =>  $cart_item['doctor_id']
                    ]);

                    $charges += $service_charges->charges ;

                }
                
            }

            return  wc_price($charges);
            
        }

    }
 // woocommerce calculate cart item Subtotal
 public function beforeCalculateTotal ($cart_object) {

    foreach ( $cart_object->cart_contents AS $cart_item ) {

        if(count($cart_item) > 0) {

            $appointment_id = $cart_item['kivicare_appointment_id'] ;

            $appointment_services = (new KCAppointmentServiceMapping())->get_by([
                'appointment_id' => $appointment_id,
            ]);

            $charges = 0 ;

            foreach ($appointment_services as $key => $value) {

                $service_charges = kcGetServiceCharges([
                    'service_id' => $value->service_id,
                    'doctor_id' =>  $cart_item['doctor_id']
                ]);

                $charges += $service_charges->charges ;

            }

        }

        $cart_item['data']->set_price( $charges );

    }

}
// woocommerce change cart item name
public function cartProductName ( $item_name, $cart_item ) {
        
    $cart_item = $this->cartServices($cart_item);
    
    return '<strong class="product-quantity"> ' . $cart_item . ' </strong> ' ;

}
   // kivicare cart services
   public function cartServices ($cart_item) {

    if(count($cart_item) > 0) {

        $appointment_id = $cart_item['kivicare_appointment_id'] ;

        $appointment_services = (new KCAppointmentServiceMapping())->get_by([
            'appointment_id' => $appointment_id,
        ]);

        $services = [] ;

        foreach ($appointment_services as $key => $value) {
            $services[$key] = kcGetServiceById($value->service_id);
        }
       
        return $services = collect($services)->implode('name', ', ');

    }

}
  // change woocommerce payment status (Active/Inactive)
  public function changeWooCommercePaymentStatus ($data) {
    return (new KCProHelper)->updateOption('woocommerce_payment', $data['status']);
}

public function onWoopaymentComplete () {
}

public function getWooCommercePaymentStatus () {
    return (new KCProHelper)->getOption('woocommerce_payment');
}

}