<?php 

namespace ProApp\filters ;
use App\baseClasses\KCBase;

class KCProSettingFilters  extends KCBase {
    public function __construct() {
        add_filter('kcpro_get_encounter_setting', [$this, 'getEncounterModule']);
        add_filter('kcpro_save_prescription_setting', [$this, 'savePrescriptionModule']);
        add_filter('kcpro_get_prescription_list', [$this, 'getPrescriptionModule']);
        add_filter('kcpro_get_list', [$this, 'getList']);
    }
    public function getList(){
        $prefix = KIVI_CARE_PRO_PREFIX;
        $encounter_modules = get_option($prefix . 'enocunter_modules');
		if($encounter_modules !== '') {
            $data = json_decode($encounter_modules);
			$status = true ;
		} else {
			$data = [] ;
			$status = false ;
        }
        return [
            'status' => $status,
            'data'    => $data
        ];
    }
    public function getEncounterModule($settings){
        if(isset($settings)){
            $prefix = KIVI_CARE_PRO_PREFIX;
            update_option( $prefix. 'enocunter_modules', json_encode($settings['encounter_module']));
            return [
                'status' => true,
                'message' => esc_html__('Setting update successfully', 'kcp-lang')

            ];
        }else{
            return [
                'status' => false,
                'message' => esc_html__('Failed to update  setting', 'kcp-lang')
            ];
        }
    }
    public function savePrescriptionModule($settings){
        if(isset($settings)){
            $prefix = KIVI_CARE_PRO_PREFIX;
            update_option( $prefix. 'prescription_module', json_encode($settings['prescription_module']));
            return [
                'status' => true,
                'message' => esc_html__('Setting update successfully', 'kcp-lang')

            ];
        }else{
            return [
                'status' => false,
                'message' => esc_html__('Failed to update  setting', 'kcp-lang')
            ];
        }
    }
    public function getPrescriptionModule($settings){
        $prefix = KIVI_CARE_PRO_PREFIX;
        $prescription_modules = get_option($prefix . 'prescription_module');
		if($prescription_modules !== '') {
            $data = json_decode($prescription_modules);
			$status = true ;
		} else {
			$data = [] ;
			$status = false ;
        }
        return [
            'status' => $status,
            'data'    => $data
        ];
    }
}