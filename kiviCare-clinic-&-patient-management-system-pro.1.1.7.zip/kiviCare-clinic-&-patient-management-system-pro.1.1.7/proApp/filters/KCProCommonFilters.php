<?php

namespace ProApp\filters ;
use App\baseClasses\KCBase;

class KCProCommonFilters extends KCBase {

    public function __construct() {
        add_filter('kcpro_get_module_list', [$this, 'getProModuleList']);
    }
    public function getProModuleList ($data) {

        $modules = kcGetModules();

        if(count($modules->kivicare_pro_feature) > 0) {
            foreach ($modules->kivicare_pro_feature as $module ) {
                if(!isset($module->isProActive)) {
                    $module->isProActive = '1' ;
                }
            }
        }

        return $modules ;
    }

}


