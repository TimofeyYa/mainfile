<?php 

namespace ProApp\filters ;
use App\baseClasses\KCBase;
use App\models\KCAppointment;
use App\models\KCBill;
use App\models\KCClinic;
use App\models\KCDoctorClinicMapping;
use App\models\KCPatientClinicMapping;
use App\models\KCReceptionistClinicMapping;
class KCProDashboardFilters  extends KCBase {
    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
        add_filter('kcpro_get_doctor_dashboard_detail', [$this, 'getDashboardDetail']);
    }
    public function getDashboardDetail($details){
        if($details['user_detail']->roles[0] === 'kiviCare_doctor'){
            $appointments_table = $this->db->prefix . 'kc_' . 'appointments';
            $service_table = $this->db->prefix . 'kc_' . 'service_doctor_mapping';
            $appointments = collect(( new KCAppointment() )->get_by(['doctor_id' => $details['user_id']]));
            $today = date("Y-m-d");  
            $todayAppointments= $appointments->where('appointment_start_date', $today);
            $query = "SELECT   `patient_id` FROM {$appointments_table} WHERE `doctor_id` = ".$details['user_id'];
            $patients = collect( $this->db->get_results( $query, OBJECT ) )->unique( 'patient_id' );
            $service = "SELECT  * FROM {$service_table} WHERE `doctor_id` = ".$details['user_id'];
            $service=collect( $this->db->get_results( $service, OBJECT ) );
            $data = [
                'patient_count' => count($patients),
                'appointment_count' => count($appointments),
                'today_count'=>count($todayAppointments),
                'service' => count($service),
            ];
            return [
                'data'=> $data,
                'status' => true,
                'message' => esc_html__('doctor dashboard', 'kcp-lang')
            ];
        }else if($details['user_detail']->roles[0] === 'administrator'){
            $patients = get_users([
                'role' => $this->getPatientRole()
            ]);
            $doctors = get_users([
                'role' => $this->getDoctorRole()
            ]);
            $appointment = collect((new KCAppointment())->get_all())->count();
            $config = kcGetModules();
            $modules = collect($config->module_config)->where('name','billing')->where('status', 1)->count();
            $bills = 0;
            if($modules > 0){
                $bills = collect((new KCBill())->get_all())->sum('actual_amount');
            }
            $data = [
                'patient_count' => count($patients),
                'doctor_count'  => count($doctors),
                'appointment_count' => $appointment,
                'revenue'   => $bills,
            ];
            return [
                'data'=> $data,
                'status' => true,
            ];
        }else if($details['user_detail']->roles[0] === 'kiviCare_clinic_admin'){
            $clinic = collect(( new KCClinic() )->get_by(['clinic_admin_id' => $details['user_id']]));
            $clinic_id  = isset($clinic[0]->id) ? $clinic[0]->id : 0;
            $doctors =  collect(( new KCDoctorClinicMapping() )->get_by(['clinic_id' => $clinic_id ]));
            $patients =  collect(( new KCPatientClinicMapping() )->get_by(['clinic_id' => $clinic_id ]));
            $appointments = collect((new KCAppointment())->get_by(['clinic_id' => $clinic_id ]))->pluck('id')->toArray();
            $config = kcGetModules();
            $modules = collect($config->module_config)->where('name','billing')->where('status', 1)->count();
            $bills = 0;
            if($modules > 0){
                $bills = collect((new KCBill())->get_by(['payment_status' => 'paid' ]));
                $revenue = $bills->whereIn('appointment_id', $appointments);
                $revenue = $revenue->sum('actual_amount');
            }
            $data = [
                'doctor_count'=>count($doctors),
                'patient_count' => count($patients),
                'appointment_count' => count($appointments),
                'revenue'   => $revenue,
            ];
            return [
                'data'=> $data,
                'status' => true,
            ];
           
        }else if($details['user_detail']->roles[0] === 'kiviCare_receptionist'){
            $clinic = collect(( new KCReceptionistClinicMapping() )->get_by(['receptionist_id' => $details['user_id']]));
            $clinic_id  = isset($clinic[0]->id) ? $clinic[0]->id : 0;

            $doctors =  collect(( new KCDoctorClinicMapping() )->get_by(['clinic_id' => $clinic_id ]));

            $patients =  collect(( new KCPatientClinicMapping() )->get_by(['clinic_id' => $clinic_id ]));

            $appointments = collect((new KCAppointment())->get_by(['clinic_id' => $clinic_id ]))->pluck('id')->toArray();
             
            $config = kcGetModules();
            $modules = collect($config->module_config)->where('name','billing')->where('status', 1)->count();
            $bills = 0;
            if($modules > 0){
                $bills = collect((new KCBill())->get_by(['payment_status' => 'paid' ]));
                $revenue = $bills->whereIn('appointment_id', $appointments);
                $revenue = $revenue->sum('actual_amount');
            }
            $data = [
                'doctor_count'=>count($doctors),
                'patient_count' => count($patients),
                'appointment_count' => count($appointments),
                'revenue'   => $revenue,
            ];
            return [
                'data'=> $data,
                'status' => true,
            ];
        }else{
            wp_die();
        }
    }
}