<?php
namespace ProApp\baseClasses;
namespace ProApp\filters;
use App\baseClasses\KCBase;
use ProApp\baseClasses\KCProHelper;

use App\models\KCAppointment;
use App\models\KCClinic;
use App\models\KCAppointmentCalenderMapping;
use App\models\KCAppointmentServiceMapping;
use App\models\KCReceptionistClinicMapping;
use App\models\KCService;

use Google_Service_Calendar;
use Google_Service_Calendar_Event;

class KCProGoogleCalenderFilters extends KCBase {
    public function __construct() {
		global $wpdb;
        $this->db = $wpdb;
        add_filter('kcpro_saved_google_config', [$this, 'saveGoogleCalSetting']);
        add_filter('kcpro_edit_google_cal', [$this, 'editGoogleCalSetting']);

        add_filter('kcpro_connect_doctor', [$this, 'connectDoctor']);
        add_filter('kcpro_disconnect_doctor', [$this, 'disConnectDoctor']);

        add_filter('kcpro_save_appointment_event', [$this, 'addEventCalender']);
        add_filter('kcpro_remove_appointment_event', [$this, 'removeEventCalender']);

        add_filter('kcpro_save_google_event_template', [$this, 'saveGoogleEventTemplate']);
        add_filter('kcpro_get_google_event_template', [$this, 'getGoogleEventTemplate']);


        add_filter('kcpro_patient_google_cal', [$this, 'savePatientCal']);
        add_filter('kcpro_patient_edit_google_cal', [$this, 'editPatientCal']);
        
    }
    public function saveGoogleCalSetting($setting){
        try{
            if(isset($setting)){
                $config = array(
                    'client_id' =>$setting['data']['client_id'],
                    'client_secret'=>$setting['data']['client_secret'],
                    'enableCal'=>$setting['data']['enableCal']
                );
                update_option( KIVI_CARE_PRO_PREFIX . 'google_cal_setting',$config );
                return [
                    'status' => true,
                    'message' => esc_html__('Save google setting successfully', 'kcp-lang')
                ];
            }
        }catch (Exception $e) {
            return [
                'status' => false,
                'message' => esc_html__('Google setting not saved', 'kcp-lang')
            ];
        }

    }
    public function editGoogleCalSetting(){
        $get_googlecal_data = get_option(KIVI_CARE_PRO_PREFIX . 'google_cal_setting',true);

        if ( gettype($get_googlecal_data) != 'boolean' ) {
          return [
              'data'=> $get_googlecal_data,
              'status' => true,
          ];
        } else {
          return [
              'data'=> [],
              'status' => false,
          ];
        }
    }

    public function connectDoctor($conn){
        $client = KCProHelper::get_client();
        try{
            if ($client->isAccessTokenExpired()) {
                if ($client->getRefreshToken()) {
                    $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
                }else{
                    $auth_code = $client->authenticate(trim($conn['code']));
                    $access_token = $client->getAccessToken();
                    $doctor_config = update_user_meta($conn['id'], 'google_cal_access_token',json_encode($access_token) );
                    update_user_meta($conn['id'], KIVI_CARE_PRO_PREFIX.'google_cal_connect','on' );
                    update_user_meta($conn['id'],KIVI_CARE_PRO_PREFIX.'doctor_calender_id' ,KCProHelper::get_selected_calendar_id($conn['id']) );
                    return [
                      'status' => true,
                      'message' => esc_html__('Google Calendar Connected', 'kcp-lang')
                    ];
                }
            }
           
        }catch (\Throwable $th) {
          return [
            'status' => false,
            'message' => $th
          ];
        }
       
    }
    public function disConnectDoctor($id){
      try{
        $get_access_token = get_user_meta($id['id'],'google_cal_access_token',true);
        if($get_access_token){
          delete_user_meta($id['id'],'google_cal_access_token');
          delete_user_meta($id['id'],KIVI_CARE_PRO_PREFIX.'doctor_calender_id');
          update_user_meta($id['id'], KIVI_CARE_PRO_PREFIX.'google_cal_connect','off' );
        }
        return [
          'status' => true,
          'message' => esc_html__('Google Calendar Disconnected', 'kcp-lang')
        ];
      }catch (\Throwable $th) {
        return [
          'status' => false,
          'message' => $th
        ];
      }
     
    }

    public function addEventCalender($eventData){
        global $wpdb;
        $table_name =  $wpdb->prefix . 'users';
        $post_table_name = $wpdb->prefix . 'posts';
        $appointment = (new KCAppointment())->get_by([ 'id' => $eventData['appoinment_id']], '=', true);
        $doctor_enable = get_user_meta($appointment->doctor_id, KIVI_CARE_PRO_PREFIX.'google_cal_connect',true);

        $receptinist_id  = (new KCReceptionistClinicMapping())->get_by(['clinic_id'=>$appointment->clinic_id] ,'=',true);
        $receptinist_enable = get_user_meta( $receptinist_id->receptionist_id, KIVI_CARE_PRO_PREFIX.'google_cal_connect',true);

        if(!empty($doctor_enable) || !empty($receptinist_enable)){
          $appointment_service = (new KCAppointmentServiceMapping())->get_by([ 'appointment_id' => $eventData['appoinment_id']], '=', true);
          $book_service = (new KCService())->get_by([ 'id' => $appointment_service->service_id], '=', true);
  
          $clinicData = (new KCClinic())->get_by(['id'=>$appointment->clinic_id] ,'=',true);
         
          $clinicAddress = $clinicData->address.','.$clinicData->city.','.$clinicData->country;
  
          $query = "SELECT * FROM {$table_name} WHERE `ID` = '{$appointment->patient_id}' ";
          $patient_data = $wpdb->get_results($query, OBJECT);
          
          if(!empty($receptinist_enable)){
            $calendar_id = KCProHelper::get_selected_calendar_id($receptinist_id->receptionist_id);
            $client = KCProHelper::get_authorized_client_for_doctor($receptinist_id->receptionist_id);
          }
          else if(!empty($doctor_enable)){
            $calendar_id = KCProHelper::get_selected_calendar_id($appointment->doctor_id);
            $client = KCProHelper::get_authorized_client_for_doctor($appointment->doctor_id);
          }
          if($client){
              $google_cal_service = new Google_Service_Calendar($client);
              $gcalmapping = new KCAppointmentCalenderMapping();
  
              $google_calendar_event_id = $gcalmapping->get_by(['appointment_id' => $eventData['appoinment_id']], '=', true);
              $google_calendar_event_id = $google_calendar_event_id->event_value;
  
            
              $args['post_name'] = strtolower(KIVI_CARE_PRO_PREFIX.'default_event_template');
              $args['post_type'] = strtolower(KIVI_CARE_PRO_PREFIX.'gcal_tmp') ;
          
              $query = "SELECT * FROM $post_table_name WHERE `post_name` = '" . $args['post_name'] . "' AND `post_type` = '".$args['post_type']."' AND post_status = 'publish' ";
              $check_exist_post = $wpdb->get_results($query, ARRAY_A);
  
              $calender_title = $check_exist_post[0]['post_title'];
              $calender_content = $check_exist_post[0]['post_content'];
              
              $key  =  ['{{service_name}}','{{clinic_name}}'];
              foreach($key as $item => $value ){
                  switch ($value) {
                      case '{{service_name}}':
                          $calender_title = str_replace($value, $book_service->name, $calender_title);
                          break;
                      case '{{clinic_name}}':
                          $calender_content = str_replace($value, $clinicData->name, $calender_content);
                          break;
                  }
              }
  
              try {
                
                if($appointment->status == '1'){
                    $timezone = get_option('timezone_string');
                    date_default_timezone_set($timezone);
                    $format = 'Y-m-d\TH:i:sP';
                    $start = date($format, strtotime( $appointment->appointment_start_date.$appointment->appointment_start_time));
                    $end = date($format, strtotime( $appointment->appointment_end_date.$appointment->appointment_end_time));
                    
                    $event = new Google_Service_Calendar_Event(array(
                      'summary' => $calender_title,
                      'location' => $clinicAddress,
                      'description' =>  $calender_content,
                      'start' => array(
                        'dateTime' => $start,
                        'timeZone' => $timezone,
                      ),
                      'end' => array(
                        'dateTime' => $end,
                        'timeZone' => $timezone,
                      ),
                    ));
                  
                    if(count($google_calendar_event_id) > 0){
                      $get_old_doctor = $gcalmapping->get_by(['appointment_id' => $eventData['appoinment_id']], '=', true);
                      $old_doctor = $get_old_doctor->doctor_id;
                      $new_doctor = $appointment->doctor_id;
                  
                      if($new_doctor !=  $old_doctor ){
                        try{
                          $old_doctor_calender_id = KCProHelper::get_selected_calendar_id($old_doctor);
                          $old_doctor_access_token = KCProHelper::get_authorized_client_for_doctor($old_doctor);
                          if($old_doctor_access_token){
                              $g_service = new Google_Service_Calendar($old_doctor_access_token);
                              $cal_mapping_data = (new KCAppointmentCalenderMapping())->get_by([ 'event_value' => $google_calendar_event_id], '=', true);
                              if($cal_mapping_data){
                                $g_service->events->delete($old_doctor_calender_id, $cal_mapping_data->event_value);
                                $old_doctor_deleted_event = ( new KCAppointmentCalenderMapping() )->delete( [ 'event_value' =>  $cal_mapping_data->event_value ] );
  
                                if($old_doctor_deleted_event){
                                    $new_doctor_calender_id = KCProHelper::get_selected_calendar_id($new_doctor);
                                    $new_doctor_access_token = KCProHelper::get_authorized_client_for_doctor($new_doctor);
                                    if($new_doctor_access_token){
                                      $new_service = new Google_Service_Calendar($new_doctor_access_token);
                                      $event = $google_cal_service->events->insert($new_doctor_calender_id, $event);
                                      $gcalmapping->save_event_key('google_calendar_event_id', $event->getId(),$eventData['appoinment_id'],$appointment->doctor_id);  
                                    }
  
                                }
                              }
                          }
                        }catch (\Throwable $th) {
                          dd($th);
                        }
                        
                        
                      }else{
                        $event = $google_cal_service->events->update($calendar_id, $google_calendar_event_id, $event);
                      }
                      
                      // Existing google event
                      return [
                        'status' => true,
                      ];
                    }else{
                      // new event in google cal
                      $event = $google_cal_service->events->insert($calendar_id, $event);
                      $gcalmapping->save_event_key('google_calendar_event_id', $event->getId(),$eventData['appoinment_id'],$appointment->doctor_id);
      
                      return [
                        'status' => true,
                      ];
                    }
                  
                }else{
                  self::removeEventCalender( $eventData);
                }
              
              }catch (\Throwable $th) {
                  dd($th);
              }
          }
        }else{
          $get_old_doctor = (new KCAppointmentCalenderMapping())->get_by(['appointment_id' => $eventData['appoinment_id']], '=', true);
          $old_doctor = $get_old_doctor->doctor_id;

          $old_doctor_calender_id = KCProHelper::get_selected_calendar_id($old_doctor);
          $old_doctor_access_token = KCProHelper::get_authorized_client_for_doctor($old_doctor);

          if($old_doctor_access_token){
            $g_service = new Google_Service_Calendar($old_doctor_access_token);
            $cal_mapping_data = (new KCAppointmentCalenderMapping())->get_by([ 'event_value' => $get_old_doctor->event_value], '=', true);
            if($cal_mapping_data){
              $g_service->events->delete($old_doctor_calender_id, $cal_mapping_data->event_value);
              $old_doctor_deleted_event = ( new KCAppointmentCalenderMapping() )->delete( [ 'event_value' =>  $cal_mapping_data->event_value ] );
            }
            return [
              'status' => true,
            ];
          }
        }

    }
    public function removeEventCalender($data){
      $appointment = (new KCAppointment())->get_by([ 'id' => $data['appoinment_id']], '=', true);
      $calendar_id = KCProHelper::get_selected_calendar_id($appointment->doctor_id);
      $client = KCProHelper::get_authorized_client_for_doctor($appointment->doctor_id);
  
  
      if($client){
        $g_service = new Google_Service_Calendar($client);
        $cal_mapping_data = (new KCAppointmentCalenderMapping())->get_by([ 'appointment_id' => $data['appoinment_id']], '=', true);
        
        $google_calendar_event_id = $cal_mapping_data->event_value;
        if($google_calendar_event_id){
          $g_service->events->delete($calendar_id, $google_calendar_event_id);
         ( new KCAppointmentCalenderMapping() )->delete( [ 'appointment_id' => $data['appoinment_id'] ] );
        }
      }
    }

    public function saveGoogleEventTemplate($template){
      foreach ($template['data'] as $key => $value) {
        wp_update_post($value);
      }
  
      return [
        'status' => true,
        'message' => esc_html__('Google template  saved successfully.', 'kcp-lang')
      ];
    }
    public function getGoogleEventTemplate(){
      $prefix = KIVI_CARE_PRO_PREFIX;
      $google_event_template = $prefix.'gcal_tmp' ;
      $args['post_type'] = strtolower($google_event_template);
      $gogle_template_result = get_posts($args);
      $gogle_template_result = collect($gogle_template_result)->unique('post_title')->sortBy('ID');
      if ($gogle_template_result) {
              return [
                  'status' => true,
                  'data'=> $gogle_template_result,
              ];
      } else {
        return [
          'status' => false,
          'data'=> [],
        ];
		  }
    }
    public function savePatientCal($data){  
      try{
        if(isset($data)){
           
            update_option( KIVI_CARE_PRO_PREFIX . 'patient_cal_setting',$data['data']['pCal'] );
            return [
                'status' => true,
                'message' => esc_html__('Patient Calender enable', 'kcp-lang')
            ];
        }
    }catch (Exception $e) {
        return [
            'status' => false,
            'message' => esc_html__('Patient Calender disable', 'kcp-lang')
        ];
    }
    }
    public function editPatientCal(){  
      $get_patient_cal = get_option(KIVI_CARE_PRO_PREFIX . 'patient_cal_setting',true);

      if ( gettype($get_patient_cal) != 'boolean' ) {
        return [
            'data'=> $get_patient_cal,
            'status' => true,
        ];
      } else {
        return [
            'data'=> [],
            'status' => false,
        ];
      }
   
    }
}