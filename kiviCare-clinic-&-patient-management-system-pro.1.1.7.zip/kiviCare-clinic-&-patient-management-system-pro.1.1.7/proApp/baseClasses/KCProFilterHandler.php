<?php

namespace ProApp\baseClasses ;
use App\baseClasses\KCBase;

class KCProFilterHandler extends KCBase {

    public function init() {
        $api_folder_path = plugin_dir_path( dirname( __FILE__, 2 ) ) . 'proApp/filters/';
        $dir = scandir($api_folder_path);

        if (count($dir)) {
            foreach ($dir as $controller_name) {
                if ($controller_name !== "." && $controller_name !== "..") {
                    $controller_name = explode( ".", $controller_name)[0];
                    $this->call($controller_name);
                }
            }
        }
    }

    public function call($controllerName) {
        $controller = 'ProApp\\filters\\' . $controllerName;
        (new $controller);
    }

}


