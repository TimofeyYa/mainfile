<?php

namespace ProApp\baseClasses;

Class KCProDeactivate extends KCProBase {
    public static function init () {
        global $wpdb;
        $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}kc_proooo_appointments " );
    }
}


