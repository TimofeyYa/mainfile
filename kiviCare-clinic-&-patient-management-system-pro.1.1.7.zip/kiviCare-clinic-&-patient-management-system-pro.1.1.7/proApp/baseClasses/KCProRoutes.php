<?php

namespace ProApp\baseClasses;

class KCProRoutes {
    public function routes() {
        return array();
    }
}
