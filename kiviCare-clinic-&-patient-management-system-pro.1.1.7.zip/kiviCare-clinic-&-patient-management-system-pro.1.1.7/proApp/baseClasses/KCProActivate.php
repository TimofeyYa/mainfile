<?php

namespace ProApp\baseClasses;
use ProApp\filters\KCProPaymentFilter;
class KCProActivate  {

    public static function activate() {
        (new KCProGetDependency('kivicare-clinic-management-system', 'kc-lang'))->getPlugin();
        (new self())->migrateDatabase();
        (new self())->addModuleConfig();
		(new self())->addDefaultSMSTemplate();
		
		


	
        add_option( KIVI_CARE_PRO_PREFIX . 'theme_color','#4874dc');
        add_option( KIVI_CARE_PRO_PREFIX . 'theme_mode','false');
        add_option( KIVI_CARE_PRO_PREFIX . 'admin_lang','en' );
        
        if (!(new KCProHelper)->getOption('woocommerce_payment')) {
			(new KCProHelper)->updateOption('woocommerce_payment', 'off');
		}	
    }

    public function init() {
		$woocommerceFilers = (new KCProPaymentFilter) ;
		(new self())->addDefaultGoogleTemplate();
		(new self())->migrateTable();
		$status = $this->isWooCommerceActive();
		if($status) {

			// woocommerce filers
			add_filter( 'kcpro_woocommerce_add_to_cart',              [ $woocommerceFilers, 'wooocommerceAddToCart']);
			add_filter( 'woocommerce_cart_item_price',              [ $woocommerceFilers, 'cartProductPrice'], 10, 3 );
			add_action( 'woocommerce_before_calculate_totals',      [ $woocommerceFilers, 'beforeCalculateTotal'], 10, 1 );
			add_filter( 'woocommerce_cart_item_name',               [ $woocommerceFilers, 'cartProductName'], 10, 2 );
			add_action( 'woocommerce_order_status_completed',       [ $woocommerceFilers, 'onWoopaymentComplete'], 10, 1 );
			add_filter( 'kcpro_change_woocommerce_module_status',     [ $woocommerceFilers, 'changeWooCommercePaymentStatus']);
			add_filter( 'kcpro_get_woocommerce_module_status',        [ $woocommerceFilers, 'getWooCommercePaymentStatus']);

			if (!(new KCProHelper)->getOption('woocommerce_payment')) {
				(new KCProHelper)->updateOption('woocommerce_payment', 'off');
			}	

		}

		add_action( 'admin_init', [$this, 'checkPluginActive'] );	
		add_action( 'rest_api_init', [$this, 'checkPluginActive'] );
        add_action( 'admin_init', [$this, 'checkPluginActive'] );
    }
    

    public function checkPluginActive () {
        $kivicare_plugin = 'kivicare-clinic-management-system/kivicare-clinic-management-system.php' ;
        if ( is_plugin_active($kivicare_plugin) ) {
            $plugins = get_plugins();
            if(isset($plugins[$kivicare_plugin]) && $plugins[$kivicare_plugin] !== '') {
                if((float) $plugins[$kivicare_plugin]['Version'] >= (float) KIVI_CARE_PRO_REQUIRED_PLUGIN_VERSION) {
                    if (class_exists('\App\baseClasses\KCRoutesHandler')) {
                        $routes = (new KCProRoutes())->routes();
                        (new \App\baseClasses\KCRoutesHandler($routes, 'ProApp\\controllers\\'))->init();
                        (new KCProFilterHandler())->init();
                    }
                } else {
                    $p_version = $plugins[$kivicare_plugin]['Version'];
                    $this->warningMessage = __( 'Warning: <b><i> KiviCare - Clinic & Patient Management System Pro </i>  </b> Requires Plugin Version :  <b> <i> KiviCare - Clinic & Patient Management System (EHR) V'.KIVI_CARE_PRO_REQUIRED_PLUGIN_VERSION.' </i></b> your current plugin version is <b> '. $p_version .' </b> .', 'kcp-lang' );
                    add_action( 'admin_notices', [$this, 'pluginWarning'] );
                }
            } else {
                $this->warningMessage = __( 'Warning: <b><i> KiviCare - Clinic & Patient Management System Pro </i>  </b> Requires <b> <i> KiviCare - Clinic & Patient Management System (EHR) </i></b>.', 'kcp-lang' );
                add_action( 'admin_notices', [$this, 'pluginWarning'] );
            }
        } else {
            $this->warningMessage = __( 'Warning: <b> <i> KiviCare - Clinic & Patient Management System (EHR) </i></b> is Inactive.', 'kcp-lang' );
            add_action( 'admin_notices', [$this, 'pluginWarning'] );
        }
		
		
    }
	public function isWooCommerceActive () {

		if (!function_exists('get_plugins')) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
	
		$plugins = get_plugins();
	
		foreach ($plugins as $key => $value) {
	
			if($value['TextDomain'] === 'woocommerce') {
	
				return true ;
				
			}
			
		}
		return false ;
	}
    public function pluginWarning() {
        $class = 'notice notice-warning';
        $message = $this->warningMessage;
        printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), $message );
    }

    public function migrateDatabase () {
        require KIVI_CARE_PRO_DIR . 'database/kcpro-appointment-db.php';
        require KIVI_CARE_PRO_DIR . 'database/kc-patient-clinic-mapping-db.php';
        require KIVI_CARE_PRO_DIR . 'database/kc-patient-report-db.php';
    }
    public function addModuleConfig(){
        $prefix = KIVI_CARE_PRO_PREFIX;
        $prescription_module =[
			'prescription_module_config' => [
				[
                    'name'=> 'prescription',
                    'label' => 'Prescription',
                     'status' => '1'
				]
			],
		];	
        delete_option($prefix.'prescription_module');
		add_option( $prefix.'prescription_module', json_encode($prescription_module));

        $encounter_modules =[
			'encounter_module_config' => [
				[
					'name' => 'problem',
					'label' => 'Problem',
					'status' => '1'
				],
				[
					'name' => 'observation',
					'label' => 'Observations',
					'status' => '1'
				],
				[
					'name' => 'note',
					'label' => 'Note',
					'status' => '1'
				]
			],
		];	
		delete_option($prefix.'enocunter_modules');
		add_option( $prefix.'enocunter_modules',json_encode($encounter_modules));

        $lang_option = [
			'lang_option' => [
				[
					'label' => 'English',
					'id' => 'en'
				],
				[
					'label' => 'Arabic',
					'id' => 'ar'
				],
                [
					'label' => 'Greek',
					'id' => 'gr'
				],
                [
					'label' => 'Franch',
					'id' => 'fr'
				]
			],
		];	
        delete_option($prefix.'lang_option');
		add_option( $prefix.'lang_option',json_encode($lang_option));
    }
    public function addDefaultSMSTemplate () {

		$prefix = KIVI_CARE_PRO_PREFIX;
		$sms_template = $prefix.'sms_tmp' ;
		$posts = get_posts('post_type='.$sms_template);
		$count = count($posts);
		if($count == 0) {
			$default_sms_template = [
				[
					'post_name' => $prefix.'add_appointment',
					'post_content' => '<p> Welcome to KiviCare ,</p><p> Your appointment has been booked  successfully on </p><p> {{appointment_date}}  , Time : {{appointment_time}}  </p><p> Thank you. </p>',
					'post_title' => 'Appointment Add SMS Template',
					'post_type' => $sms_template,
					'post_status' => 'publish',
				],
				[
					'post_name' => $prefix.'encounter_close',
					'post_content' => '<p>Welcome to KiviCare ,</p><p>Your appointment has been closed with your total amount {{total_amount}}  </p><p>Thank you.</p>',
					'post_title' => 'Encounter SMS Template',
					'post_type' => $sms_template,
					'post_status' => 'publish',
				]
			];
			
			foreach ($default_sms_template as $sms_template) {
				wp_insert_post($sms_template) ;
			}
		}

	}
	public function addDefaultGoogleTemplate(){
		$prefix = KIVI_CARE_PRO_PREFIX;
		$google_event_template = $prefix.'gcal_tmp' ;
		$posts = get_posts('post_type='.$google_event_template);
		$count = count($posts);

		if($count == 0) {

			$my_post = array(
				'post_title' => '{{service_name}}',
				'post_content'  =>' Appointment booked at {{clinic_name}}',
				'post_status'   => 'publish',
				'post_type' => $google_event_template,
				'post_name' => $prefix.'default_event_template',
		  		);

		  wp_insert_post( $my_post );
		}

	}
	public function migrateTable(){
		require KIVI_CARE_PRO_DIR . 'database/kcpro-gcal_appointment_mapping-db.php';
	}

}


